export interface Staff {
    staffCode: number;
    firstName: string;
    lastName: string;
    position: string;
    phone: string;
}