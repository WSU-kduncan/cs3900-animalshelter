export interface Pet{
    id: number;
    name: string;
    species: string;
    breed: string;
    sex: string;
    weight: number | null; 
    intake_date: string;
    age: number | null;
    pet_status: string; 


    

}