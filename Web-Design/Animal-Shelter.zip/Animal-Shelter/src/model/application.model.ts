export interface Application {
    applicationId: number;
    petId: number;
    adopterId: number;
    applicationDate: string;
    applicationStatus: string;
}